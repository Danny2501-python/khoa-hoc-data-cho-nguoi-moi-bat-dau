DataLab GPBank · dữ liệu thực hành hoàn toàn giả lập

1. transactions.csv có 1.002 dòng, gồm 1.000 hợp lệ, 1 lặp,
   1 phải cách ly do tài khoản không tồn tại.
2. accounts.csv có 100 tài khoản. cif_mapping.csv nối 100 CIF nguồn
   về 50 CIF chuẩn. Khóa nối là source_system + source_cif.
3. Tính kiểm soát theo ngày nghiệp vụ rồi so với expected_eod.csv.
   Không đưa expected_eod.csv vào pipeline như một nguồn đầu vào.
4. Chạy lại cùng batch, kiểm số dòng và tổng tiền không tăng.

Tổng VND raw: 69619637
Tổng hợp lệ: 69568500
Tổng lặp: 1137
Tổng cách ly: 50000
